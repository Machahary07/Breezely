// Default / Production environment config
export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyBmkJrZ7Udts1okkBYzCvLa2na9E_0quY8",
    authDomain: "breezely-001.firebaseapp.com",
    projectId: "breezely-001",
    storageBucket: "breezely-001.firebasestorage.app",
    messagingSenderId: "399932147269",
    appId: "1:399932147269:web:9801b6d9a955d019bdc52c",
    measurementId: "G-2HBGNTB8L5"
  }
};
